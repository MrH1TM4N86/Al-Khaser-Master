# ATAIdentifyDump

ATAIdentifyDump dumps ATA IDENTIFY data from physical disks. This data is useful for identifying VMs.

You must run this tool as an administrator.