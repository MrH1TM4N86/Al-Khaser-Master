# Struct Dump Codegen

This is a LINQpad script to turn a struct definition into C++ code that prints out its contents. So far it supports USHORT, ULONG, and UCHAR.

This was written specifically for IDENTIFY_DEVICE_DATA in order to speed up writing ATAIdentifyDump.

This can probably be used for similar structs too, so it might be useful elsewhere.