#pragma once

VOID analysis_tools_process();

/*

avpui.exe 
avgui.exe
bdagent.exe

*/