#pragma once

BOOL CreateRemoteThread_Injection();