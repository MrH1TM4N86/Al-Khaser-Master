#pragma once

BOOL NtCreateThreadEx_Injection();
