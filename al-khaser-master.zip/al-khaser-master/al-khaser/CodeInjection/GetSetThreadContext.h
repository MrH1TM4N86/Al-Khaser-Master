#pragma once

BOOL GetSetThreadContext_Injection();
