#pragma once

BOOL SetWindowsHooksEx_Injection(); 