#pragma once

VOID xen_process();
BOOL xen_check_mac();