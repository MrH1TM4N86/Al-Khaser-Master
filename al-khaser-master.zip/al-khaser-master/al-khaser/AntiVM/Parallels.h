#pragma once

VOID parallels_process();
BOOL parallels_check_mac();