#pragma once


VOID virtual_pc_process();
VOID virtual_pc_reg_keys();
