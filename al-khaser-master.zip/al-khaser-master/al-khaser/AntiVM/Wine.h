#pragma once

BOOL wine_exports();
VOID wine_reg_keys();