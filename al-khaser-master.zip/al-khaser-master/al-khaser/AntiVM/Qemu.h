#pragma once

VOID qemu_reg_key_value();
VOID qemu_processes();
BOOL qemu_firmware_ACPI();
BOOL qemu_firmware_SMBIOS();
