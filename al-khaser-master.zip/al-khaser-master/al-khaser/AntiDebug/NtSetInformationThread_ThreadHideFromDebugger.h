#pragma once

BOOL NtSetInformationThread_ThreadHideFromDebugger();