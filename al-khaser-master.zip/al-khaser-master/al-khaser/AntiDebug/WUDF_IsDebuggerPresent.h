BOOL WUDF_IsAnyDebuggerPresent();
BOOL WUDF_IsKernelDebuggerPresent();
BOOL WUDF_IsUserDebuggerPresent();
