#pragma once

BOOL VirtualAlloc_WriteWatch_BufferOnly();
BOOL VirtualAlloc_WriteWatch_APICalls();
BOOL VirtualAlloc_WriteWatch_IsDebuggerPresent();
BOOL VirtualAlloc_WriteWatch_CodeWrite();