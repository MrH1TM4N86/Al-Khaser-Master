#pragma once

BOOL NtQueryInformationProcess_ProcessDebugPort();