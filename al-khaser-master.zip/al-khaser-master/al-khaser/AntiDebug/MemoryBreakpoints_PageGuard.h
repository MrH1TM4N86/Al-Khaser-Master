#pragma once

BOOL MemoryBreakpoints_PageGuard();