#pragma once

BOOL HeapForceFlags();