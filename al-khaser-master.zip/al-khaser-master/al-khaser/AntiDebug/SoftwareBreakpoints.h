#pragma once

BOOL SoftwareBreakpoints();
