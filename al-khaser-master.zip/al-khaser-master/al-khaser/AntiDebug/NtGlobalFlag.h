#pragma once

BOOL NtGlobalFlag();