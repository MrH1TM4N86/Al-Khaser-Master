#pragma once

BOOL SetHandleInformatiom_ProtectedHandle();